#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 10:55:48 2022

@author: shanrahan
"""
#ExtractFromTemmerman.py
################################### README ################################### 
# Code is written to extract data from results of Temmerman and Leschziner 2001.
# Dataset is available at https://turbmodels.larc.nasa.gov/Other_LES_Data/2dhill_periodic.html
###############################################################################

import os
import numpy as np
from matplotlib import pyplot as plt
from scipy.interpolate import griddata, interp2d

# Import Data from Temmerman
os.chdir('/Users/shanrahan/Dropbox/Mac/Documents/PhD/Cases/DataProcessing/Periodic Hill')

with open('hill_LES_avgresults.dat','r') as f:
    lines = f.readlines()

l =[]
for line in lines[23:]:
    var = np.asarray(line.split())
    l = np.concatenate([l,var.astype(float)])
    
x_ref = l[:(196*128)]
y_ref = l[(196*128):2*(196*128)]
p_ref = l[(2*(196*128)):3*(196*128)]
u_ref = l[(3*(196*128)):4*(196*128)]
v_ref = l[(4*(196*128)):5*(196*128)]
w_ref = l[(5*(196*128)):6*(196*128)]
nu_ref = l[(6*(196*128)):7*(196*128)]
uu_ref = l[(7*(196*128)):8*(196*128)]
vv_ref = l[(8*(196*128)):9*(196*128)]
ww_ref = l[(9*(196*128)):10*(196*128)]
uv_ref = l[(10*(196*128)):11*(196*128)]
vw_ref = l[(11*(196*128)):12*(196*128)]
k_ref = l[(12*(196*128)):13*(196*128)]

x_ref = x_ref.reshape((128, 196))
y_ref = y_ref.reshape((128,196))
u_ref = u_ref.reshape((128,196))
v_ref = v_ref.reshape((128,196))
p_ref = p_ref.reshape((128,196))
nu_ref = nu_ref.reshape((128,196))
uu_ref = uu_ref.reshape((128,196))
uv_ref = uv_ref.reshape((128,196))
vv_ref= vv_ref.reshape((128,196))

del(w_ref, ww_ref, vw_ref, k_ref)

#%% Build Mesh from Cartesian Mesh

xSamp = int(1000)
ySamp = 128
Ymax = 3.035*28
#xGrid = np.linspace(0,252,xSamp)
xGrid = np.zeros([ySamp,xSamp])
yGrid = np.zeros([ySamp,xSamp])
    
    
X = np.linspace(0,126,int(xSamp/2))  #X Coord for bottom wall
Ymin = np.zeros([int(xSamp/2)])         #Y Coord for bottom wall


X1 = np.linspace(0,252, xSamp)


for i in range(int(xSamp/2)):    #Definition of hill on bottom wall
    if X[i] < 9:
        Ymin[i] = min(28, 2.800000000000E+01 + 0.000000000000E+00*X[i] + 6.775070969851E-03*X[i]**2 - 2.124527775800E-03*X[i]**3 )
    if (X[i]>= 9) & (X[i]<14):
        Ymin[i] = 2.507355893131E+01 + 9.754803562315E-01*X[i] - 1.016116352781E-01*X[i]**2  + 1.889794677828E-03*X[i]**3
    if (X[i]>=14) & (X[i]<20):
        Ymin[i] = 2.579601052357E+01 + 8.206693007457E-01*X[i] - 9.055370274339E-02*X[i]**2 + 1.626510569859E-03*X[i]**3
    if (X[i]>=20) & (X[i]< 30):
        Ymin[i] = 4.046435022819E+01 - 1.379581654948E+00*X[i] + 1.945884504128E-02*X[i]**2 - 2.070318932190E-04*X[i]**3
    if (X[i]>=30) & (X[i]<40):
        Ymin[i] = 1.792461334664E+01 + 8.743920332081E-01*X[i] - 5.567361123058E-02*X[i]**2  + 6.277731764683E-04*X[i]**3    
    if (X[i]>=40) & (X[i]<54):
        Ymin[i] = max(0., 5.639011190988E+01 - 2.010520359035E+00*X[i] + 1.644919857549E-02*X[i]**2 + 2.674976141766E-05*X[i]**3 )
        
    
Ymin = np.concatenate((Ymin, np.flip(Ymin)), axis =0)/28.0 # Building next hill

#scale grid stretching to new coords
profile = y_ref[:,0]

ytemp = np.zeros((profile.size))

for i in range(int(xSamp)):
    for j in range(profile.size):
        ytemp[j] = Ymin[i] + (3.035 - Ymin[i])* ( profile[j] - profile.min())/(profile.max() - profile.min())
    yGrid[:,i] = ytemp
    xGrid[:,i] = X1[i]/28.0
plt.scatter(xGrid, yGrid)    

#%% Interpolate data onto Cartesian Mesh
uGrid = griddata((x_ref.flatten(),y_ref.flatten()),u_ref.flatten(),(xGrid,yGrid),method='linear')
vGrid = griddata((x_ref.flatten(),y_ref.flatten()),v_ref.flatten(),(xGrid,yGrid),method='linear')
pGrid = griddata((x_ref.flatten(),y_ref.flatten()),p_ref.flatten(),(xGrid,yGrid),method='linear')
uuGrid = griddata((x_ref.flatten(),y_ref.flatten()),uu_ref.flatten(),(xGrid,yGrid),method='linear')
uvGrid = griddata((x_ref.flatten(),y_ref.flatten()),uv_ref.flatten(),(xGrid,yGrid),method='linear')
vvGrid = griddata((x_ref.flatten(),y_ref.flatten()),vv_ref.flatten(),(xGrid,yGrid),method='linear')

#Pad Nan values with zero
#uGrid[0,:] = 0

#%% Extract Profiles Required - Formatted to match existing databases
p11 = np.concatenate([yGrid[:,925, np.newaxis], uGrid[:,925, np.newaxis], vGrid[:,925, np.newaxis], uuGrid[:,925, np.newaxis], vvGrid[:,925, np.newaxis], uvGrid[:,925, np.newaxis]], axis = 1)
p11 = np.nan_to_num(p11, nan = 0)


p12 = np.concatenate([yGrid[:,944, np.newaxis], uGrid[:,944, np.newaxis], vGrid[:,944, np.newaxis], uuGrid[:,944, np.newaxis], vvGrid[:,944, np.newaxis], uvGrid[:,944, np.newaxis]],  axis = 1)
p12 = np.nan_to_num(p12, nan = 0)

p13 = np.concatenate([yGrid[:,962, np.newaxis], uGrid[:,962, np.newaxis], vGrid[:,962, np.newaxis], uuGrid[:,962, np.newaxis], vvGrid[:,962, np.newaxis], uvGrid[:,962, np.newaxis]], axis = 1)
p13 = np.nan_to_num(p13, nan = 0)


os.chdir('/Users/shanrahan/Dropbox/Mac/Documents/PhD/Cases/Periodic Hills/NumPH_006_10/Data/Numeric/Re_10595')
np.save('p11.npy', p11)
np.save('p12.npy', p12)
np.save('p13.npy', p13)
